JPEGCrops readme file

*** What is this? ***
The purpose of JPEGCrops is to prepare multiple JPEG images for printing.
It uses fixed aspects and the JPEGTran utility for lossless cropping.


*** Installation ***
Unpack all files to your directory of choice and run JPEGCrops.exe.
The program creates some files in the installation directory, but doesn't
change the registry. Uninstall by deleting the directory.


*** Usage ***
Add images to the list by using the "Add images..." button or by drag'n'drop.

Adjust the cropping areas with the mouse or keyboard (check the Shortcuts
menu under Help).

Press "Crop Images" and JPEGCrops will copy the cropped images to the
selected directory. The originals are left untouched.


*** Contact ***
Toke Eskildsen darkwing@daimi.au.dk
http://ekot.dk/JPEGCrops/


*** License & Distribution ***
This software is freeware for personal use, so pass it around if you like.
Please don't upload it to any shareware or freeware sites without my permission.

If you want to use this software commercially, please visit
http://ekot.dk/JPEGCrops/license.html


*** Help me ***
If you want to translate JPEGCrops to a language not yet supported,
please take a look at http://ekot.dk/JPEGCrops/translate.html and
contact me. It's quite easy to do.


*** Credits ***
jpegtran is a free utility from the Independent JPEG Group.
Please visit http://www.ijg.org for more information.

Related information and programs can be found at
http://sylvana.net/jpegcrop/

The toolkit GNU Gettext was used for localization.
Please visit http://dybdahl.dk/dxgettext/ for more information.

dEXIF from Gerry McGuire was used to remove thumbnails and change DPI
Please visit http://mcguirez.homestead.com/ for more information

ConsoleApp.pas from Martin Lafferty was used for execution of JPEGTran.
Please visit
http://cvs.sourceforge.net/cgi-bin/viewcvs.cgi/*checkout*/dxgettext/dxgettext/tools/ggfmt/ConsoleApp.pas?rev=HEAD&content-type=text/plain
for more information

Inno Setup created the installerversion.
Please visit http://www.jrsoftware.org/isinfo.php for more information